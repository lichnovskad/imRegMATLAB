function [panorama]=createPanorama(buildingScene, imOrder, RES,tforms, xLimits, yLimits, colBorder)

width  = round(xLimits(2) - xLimits(1));
height = round(yLimits(2) - yLimits(1));

% Initialize the "empty" panorama.
I = readimage(buildingScene, imOrder(1));
I = rot90(I,3);
I = imresize(I,RES);
panorama = zeros([height width 3], 'like', I);

% Width and height of panorama.

blender = vision.AlphaBlender('Operation', 'Binary mask', ...
    'MaskSource', 'Input port');  

% Create a 2-D spatial reference object defining the size of the panorama.
panoramaView = imref2d([height width], xLimits, yLimits);

S = [RES 0 0; 0 RES 0; 0 0 1];

mask = {};
images = {};
% Create the panorama.
for i = 1:numel(imOrder)
    
    I = readimage(buildingScene, imOrder(i));
    I = imresize(I,RES);
    I = rot90(I,3);
    %I = insertShape(I,'Polygon',[0 0 0 1080 1920 1080 1920 0],'LineWidth',5, 'Color', {['blue']});
    
    % Transform I into the panorama.
    tforms(i).T = S\tforms(i).T*S;
    warpedImage = imwarp(I, tforms(i), 'OutputView', panoramaView);
    images{i} = warpedImage;         

    % Generate a binary mask.    
    mask{i} = imwarp(true(size(I,1),size(I,2)), tforms(i), 'OutputView', panoramaView);
    
    % Overlay the warpedImage onto the panorama.
    %panorama = step(blender, panorama, warpedImage, mask);
    %panorama = imfuse(panorama, warpedImage, mask);
end

for i = 1:numel(imOrder)
    panorama = step(blender, panorama, images{i}, mask{i});
end
if colBorder == true
    
    K=1;
    for i = 1:numel(imOrder)

        colourNames = {'blue','red','green','yellow'};
        panorama = imoverlay(panorama, edge(mask{i}), colourNames{K});
        K = K+1;
        if K>4
            K=1;
        end
    end
end